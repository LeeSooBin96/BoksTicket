#ifndef GET_CH_H_
#define GET_CH_H_
//문자 버퍼 없이 바로 입력 - 입력받은 문자 반환
int getch(void);
#endif