#include "LoginPage.h"

#ifndef BOOKING_DETAIL_H_
#define BOOKING_DETAIL_H_

class BookingDetail
{
    public:
        void ShowBookingL(LoginPage& login);
};
#endif